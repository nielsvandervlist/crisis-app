/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/_app";
exports.ids = ["pages/_app"];
exports.modules = {

/***/ "./src/pages/_app.js":
/*!***************************!*\
  !*** ./src/pages/_app.js ***!
  \***************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {\n__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _src_routes__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../src/routes */ \"./src/routes.js\");\n/* harmony import */ var tailwindcss_tailwind_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tailwindcss/tailwind.css */ \"./node_modules/tailwindcss/tailwind.css\");\n/* harmony import */ var tailwindcss_tailwind_css__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(tailwindcss_tailwind_css__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var _styles_style_scss__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../styles/style.scss */ \"./src/styles/style.scss\");\n/* harmony import */ var _styles_style_scss__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_styles_style_scss__WEBPACK_IMPORTED_MODULE_3__);\n/* harmony import */ var _fortawesome_fontawesome_svg_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @fortawesome/fontawesome-svg-core */ \"@fortawesome/fontawesome-svg-core\");\n/* harmony import */ var _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @fortawesome/free-solid-svg-icons */ \"@fortawesome/free-solid-svg-icons\");\nvar __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_fortawesome_fontawesome_svg_core__WEBPACK_IMPORTED_MODULE_4__, _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_5__]);\n([_fortawesome_fontawesome_svg_core__WEBPACK_IMPORTED_MODULE_4__, _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);\n\n\n\n\n\n\n_fortawesome_fontawesome_svg_core__WEBPACK_IMPORTED_MODULE_4__.library.add(_fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_5__.faUser, _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_5__.faFire, _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_5__.faClock, _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_5__.faBuilding, _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_5__.faEnvelope, _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_5__.faComment, _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_5__.faBell, _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_5__.faCircleDot, _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_5__.faAngleDown, _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_5__.faPenToSquare, _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_5__.faTrashCan, _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_5__.faEllipsisVertical);\nconst App = ({ Component , pageProps  })=>/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(Component, {\n        ...pageProps\n    }, void 0, false, {\n        fileName: \"/Users/niels/bespokeweb/crisistool-app/src/pages/_app.js\",\n        lineNumber: 9,\n        columnNumber: 43\n    }, undefined);\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (App);\n\n__webpack_async_result__();\n} catch(e) { __webpack_async_result__(e); } });//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvcGFnZXMvX2FwcC5qcy5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFBeUI7QUFDUTtBQUNKO0FBQytCO0FBQ21JO0FBRS9MQSwwRUFBVyxDQUFDQyxxRUFBTSxFQUFFQyxxRUFBTSxFQUFFQyxzRUFBTyxFQUFFQyx5RUFBVSxFQUFFQyx5RUFBVSxFQUFFQyx3RUFBUyxFQUFFQyxxRUFBTSxFQUFFQywwRUFBVyxFQUFFQywwRUFBVyxFQUFFQyw0RUFBYSxFQUFFQyx5RUFBVSxFQUFFQyxpRkFBa0IsQ0FBQyxDQUFDO0FBRXpKLE1BQU1FLEdBQUcsR0FBRyxDQUFDLEVBQUVDLFNBQVMsR0FBRUMsU0FBUyxHQUFFLGlCQUFLLDhEQUFDRCxTQUFTO1FBQUUsR0FBR0MsU0FBUzs7Ozs7aUJBQUk7QUFFdEUsaUVBQWVGLEdBQUciLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9icmVlemUtbmV4dC8uL3NyYy9wYWdlcy9fYXBwLmpzPzhmZGEiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0ICcuLi8uLi9zcmMvcm91dGVzJ1xuaW1wb3J0ICd0YWlsd2luZGNzcy90YWlsd2luZC5jc3MnXG5pbXBvcnQgJy4uL3N0eWxlcy9zdHlsZS5zY3NzJ1xuaW1wb3J0IHsgbGlicmFyeSB9IGZyb20gXCJAZm9ydGF3ZXNvbWUvZm9udGF3ZXNvbWUtc3ZnLWNvcmVcIjtcbmltcG9ydCB7IGZhVXNlciwgZmFGaXJlLCBmYUNsb2NrLCBmYUJ1aWxkaW5nLCBmYUVudmVsb3BlLCBmYUNvbW1lbnQsIGZhQmVsbCwgZmFDaXJjbGVEb3QsIGZhQW5nbGVEb3duLCBmYVBlblRvU3F1YXJlLCBmYVRyYXNoQ2FuLCBmYUVsbGlwc2lzVmVydGljYWx9IGZyb20gXCJAZm9ydGF3ZXNvbWUvZnJlZS1zb2xpZC1zdmctaWNvbnNcIjtcblxubGlicmFyeS5hZGQoZmFVc2VyLCBmYUZpcmUsIGZhQ2xvY2ssIGZhQnVpbGRpbmcsIGZhRW52ZWxvcGUsIGZhQ29tbWVudCwgZmFCZWxsLCBmYUNpcmNsZURvdCwgZmFBbmdsZURvd24sIGZhUGVuVG9TcXVhcmUsIGZhVHJhc2hDYW4sIGZhRWxsaXBzaXNWZXJ0aWNhbCk7XG5cbmNvbnN0IEFwcCA9ICh7IENvbXBvbmVudCwgcGFnZVByb3BzIH0pID0+IDxDb21wb25lbnQgey4uLnBhZ2VQcm9wc30gLz5cblxuZXhwb3J0IGRlZmF1bHQgQXBwXG4iXSwibmFtZXMiOlsibGlicmFyeSIsImZhVXNlciIsImZhRmlyZSIsImZhQ2xvY2siLCJmYUJ1aWxkaW5nIiwiZmFFbnZlbG9wZSIsImZhQ29tbWVudCIsImZhQmVsbCIsImZhQ2lyY2xlRG90IiwiZmFBbmdsZURvd24iLCJmYVBlblRvU3F1YXJlIiwiZmFUcmFzaENhbiIsImZhRWxsaXBzaXNWZXJ0aWNhbCIsImFkZCIsIkFwcCIsIkNvbXBvbmVudCIsInBhZ2VQcm9wcyJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./src/pages/_app.js\n");

/***/ }),

/***/ "./src/routes.js":
/*!***********************!*\
  !*** ./src/routes.js ***!
  \***********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony import */ var ra_fetch__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ra-fetch */ \"ra-fetch\");\n/* harmony import */ var ra_fetch__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(ra_fetch__WEBPACK_IMPORTED_MODULE_0__);\n\nconst backend = ra_fetch__WEBPACK_IMPORTED_MODULE_0__.Router.api(\"backend\", `${\"http://localhost:8000\"}`).laravel().bearTokenFromCookie(\"token\").loginURL(\"/login\").logoutURL(\"/logout\").csrfURL(\"/sanctum/csrf-cookie\").index(\"users\", \"/api/users\").show(\"user\", \"/api/user\").index(\"posts\", \"/api/posts\").show(\"posts\", \"/api/posts/{id}\").store(\"posts\", \"/api/posts\", {\n    form_data: true\n}).delete(\"posts\", \"/api/posts/{id}\").index(\"post_types\", \"/api/post_types\").index(\"companies\", \"/api/companies\").show(\"companies\", \"/api/companies/{id}\").store(\"companies\", \"/api/companies\", {\n    form_data: true\n}).delete(\"companies\", \"/api/companies/{id}\").index(\"timelines\", \"/api/timelines\").show(\"timelines\", \"/api/timelines/{id}\").store(\"timelines\", \"/api/timelines\", {\n    form_data: true\n}).delete(\"timelines\", \"/api/timelines/{id}\").index(\"crises\", \"/api/crises\").show(\"crises\", \"/api/crises/{id}\").store(\"crises\", \"/api/crises\", {\n    form_data: true\n}).delete(\"crises\", \"/api/crises/{id}\");\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvcm91dGVzLmpzLmpzIiwibWFwcGluZ3MiOiI7OztBQUErQjtBQUUvQixNQUFNQyxPQUFPLEdBQUdELGdEQUFVLENBQUMsU0FBUyxFQUFFLENBQUMsRUFBRUcsdUJBQW1DLENBQUMsQ0FBQyxDQUFDLENBQzFFRyxPQUFPLEVBQUUsQ0FDVEMsbUJBQW1CLENBQUMsT0FBTyxDQUFDLENBQzVCQyxRQUFRLENBQUMsUUFBUSxDQUFDLENBQ2xCQyxTQUFTLENBQUMsU0FBUyxDQUFDLENBQ3BCQyxPQUFPLENBQUMsc0JBQXNCLENBQUMsQ0FFL0JDLEtBQUssQ0FBQyxPQUFPLEVBQUUsWUFBWSxDQUFDLENBQzVCQyxJQUFJLENBQUMsTUFBTSxFQUFFLFdBQVcsQ0FBQyxDQUV6QkQsS0FBSyxDQUFDLE9BQU8sRUFBRSxZQUFZLENBQUMsQ0FDNUJDLElBQUksQ0FBQyxPQUFPLEVBQUUsaUJBQWlCLENBQUMsQ0FDaENDLEtBQUssQ0FBQyxPQUFPLEVBQUUsWUFBWSxFQUFFO0lBQUNDLFNBQVMsRUFBRSxJQUFJO0NBQUMsQ0FBQyxDQUMvQ0MsTUFBTSxDQUFDLE9BQU8sRUFBRSxpQkFBaUIsQ0FBQyxDQUVsQ0osS0FBSyxDQUFDLFlBQVksRUFBRSxpQkFBaUIsQ0FBQyxDQUV0Q0EsS0FBSyxDQUFDLFdBQVcsRUFBRSxnQkFBZ0IsQ0FBQyxDQUNwQ0MsSUFBSSxDQUFDLFdBQVcsRUFBRSxxQkFBcUIsQ0FBQyxDQUN4Q0MsS0FBSyxDQUFDLFdBQVcsRUFBRSxnQkFBZ0IsRUFBRTtJQUFDQyxTQUFTLEVBQUUsSUFBSTtDQUFDLENBQUMsQ0FDdkRDLE1BQU0sQ0FBQyxXQUFXLEVBQUUscUJBQXFCLENBQUMsQ0FFMUNKLEtBQUssQ0FBQyxXQUFXLEVBQUUsZ0JBQWdCLENBQUMsQ0FDcENDLElBQUksQ0FBQyxXQUFXLEVBQUUscUJBQXFCLENBQUMsQ0FDeENDLEtBQUssQ0FBQyxXQUFXLEVBQUUsZ0JBQWdCLEVBQUU7SUFBQ0MsU0FBUyxFQUFFLElBQUk7Q0FBQyxDQUFDLENBQ3ZEQyxNQUFNLENBQUMsV0FBVyxFQUFFLHFCQUFxQixDQUFDLENBRTFDSixLQUFLLENBQUMsUUFBUSxFQUFFLGFBQWEsQ0FBQyxDQUM5QkMsSUFBSSxDQUFDLFFBQVEsRUFBRSxrQkFBa0IsQ0FBQyxDQUNsQ0MsS0FBSyxDQUFDLFFBQVEsRUFBRSxhQUFhLEVBQUU7SUFBQ0MsU0FBUyxFQUFFLElBQUk7Q0FBQyxDQUFDLENBQ2pEQyxNQUFNLENBQUMsUUFBUSxFQUFFLGtCQUFrQixDQUFDIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vYnJlZXplLW5leHQvLi9zcmMvcm91dGVzLmpzPzhkNjUiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtSb3V0ZXJ9IGZyb20gJ3JhLWZldGNoJ1xuXG5jb25zdCBiYWNrZW5kID0gUm91dGVyLmFwaSgnYmFja2VuZCcsIGAke3Byb2Nlc3MuZW52Lk5FWFRfUFVCTElDX0JBQ0tFTkRfVVJMfWApXG4gICAgLmxhcmF2ZWwoKVxuICAgIC5iZWFyVG9rZW5Gcm9tQ29va2llKCd0b2tlbicpXG4gICAgLmxvZ2luVVJMKCcvbG9naW4nKVxuICAgIC5sb2dvdXRVUkwoJy9sb2dvdXQnKVxuICAgIC5jc3JmVVJMKCcvc2FuY3R1bS9jc3JmLWNvb2tpZScpXG5cbiAgICAuaW5kZXgoJ3VzZXJzJywgJy9hcGkvdXNlcnMnKVxuICAgIC5zaG93KCd1c2VyJywgJy9hcGkvdXNlcicpXG5cbiAgICAuaW5kZXgoJ3Bvc3RzJywgJy9hcGkvcG9zdHMnKVxuICAgIC5zaG93KCdwb3N0cycsICcvYXBpL3Bvc3RzL3tpZH0nKVxuICAgIC5zdG9yZSgncG9zdHMnLCAnL2FwaS9wb3N0cycsIHtmb3JtX2RhdGE6IHRydWV9KVxuICAgIC5kZWxldGUoJ3Bvc3RzJywgJy9hcGkvcG9zdHMve2lkfScpXG5cbiAgICAuaW5kZXgoJ3Bvc3RfdHlwZXMnLCAnL2FwaS9wb3N0X3R5cGVzJylcblxuICAgIC5pbmRleCgnY29tcGFuaWVzJywgJy9hcGkvY29tcGFuaWVzJylcbiAgICAuc2hvdygnY29tcGFuaWVzJywgJy9hcGkvY29tcGFuaWVzL3tpZH0nKVxuICAgIC5zdG9yZSgnY29tcGFuaWVzJywgJy9hcGkvY29tcGFuaWVzJywge2Zvcm1fZGF0YTogdHJ1ZX0pXG4gICAgLmRlbGV0ZSgnY29tcGFuaWVzJywgJy9hcGkvY29tcGFuaWVzL3tpZH0nKVxuXG4gICAgLmluZGV4KCd0aW1lbGluZXMnLCAnL2FwaS90aW1lbGluZXMnKVxuICAgIC5zaG93KCd0aW1lbGluZXMnLCAnL2FwaS90aW1lbGluZXMve2lkfScpXG4gICAgLnN0b3JlKCd0aW1lbGluZXMnLCAnL2FwaS90aW1lbGluZXMnLCB7Zm9ybV9kYXRhOiB0cnVlfSlcbiAgICAuZGVsZXRlKCd0aW1lbGluZXMnLCAnL2FwaS90aW1lbGluZXMve2lkfScpXG5cbiAgICAuaW5kZXgoJ2NyaXNlcycsICcvYXBpL2NyaXNlcycpXG4gICAgLnNob3coJ2NyaXNlcycsICcvYXBpL2NyaXNlcy97aWR9JylcbiAgICAuc3RvcmUoJ2NyaXNlcycsICcvYXBpL2NyaXNlcycsIHtmb3JtX2RhdGE6IHRydWV9KVxuICAgIC5kZWxldGUoJ2NyaXNlcycsICcvYXBpL2NyaXNlcy97aWR9JylcblxuIl0sIm5hbWVzIjpbIlJvdXRlciIsImJhY2tlbmQiLCJhcGkiLCJwcm9jZXNzIiwiZW52IiwiTkVYVF9QVUJMSUNfQkFDS0VORF9VUkwiLCJsYXJhdmVsIiwiYmVhclRva2VuRnJvbUNvb2tpZSIsImxvZ2luVVJMIiwibG9nb3V0VVJMIiwiY3NyZlVSTCIsImluZGV4Iiwic2hvdyIsInN0b3JlIiwiZm9ybV9kYXRhIiwiZGVsZXRlIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./src/routes.js\n");

/***/ }),

/***/ "./node_modules/tailwindcss/tailwind.css":
/*!***********************************************!*\
  !*** ./node_modules/tailwindcss/tailwind.css ***!
  \***********************************************/
/***/ (() => {



/***/ }),

/***/ "./src/styles/style.scss":
/*!*******************************!*\
  !*** ./src/styles/style.scss ***!
  \*******************************/
/***/ (() => {



/***/ }),

/***/ "ra-fetch":
/*!***************************!*\
  !*** external "ra-fetch" ***!
  \***************************/
/***/ ((module) => {

"use strict";
module.exports = require("ra-fetch");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-dev-runtime");

/***/ }),

/***/ "@fortawesome/fontawesome-svg-core":
/*!****************************************************!*\
  !*** external "@fortawesome/fontawesome-svg-core" ***!
  \****************************************************/
/***/ ((module) => {

"use strict";
module.exports = import("@fortawesome/fontawesome-svg-core");;

/***/ }),

/***/ "@fortawesome/free-solid-svg-icons":
/*!****************************************************!*\
  !*** external "@fortawesome/free-solid-svg-icons" ***!
  \****************************************************/
/***/ ((module) => {

"use strict";
module.exports = import("@fortawesome/free-solid-svg-icons");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./src/pages/_app.js"));
module.exports = __webpack_exports__;

})();